package com.springkiki.waproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaprojectApplication.class, args);
	}

}
